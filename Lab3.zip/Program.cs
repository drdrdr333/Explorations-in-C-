﻿using Microsoft.VisualBasic;
using System.Reflection;
using System.Collections.Generic;

namespace Lab3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Part I
            string divider = new string('=', 40);
            Console.WriteLine("Part I");
            Console.WriteLine(divider);
            VideoTypes vidType = VideoTypes.Film;
            Console.WriteLine(vidType);


            var movie1 = (type: VideoTypes.Laserdisk, title: "Lion King", yearCreated: 1999);
            var movie2 = (type: VideoTypes.Bluray, title: "Little Rascals", yearCreated: 1996);
            var movie3 = (type: VideoTypes.Film, title: "ET: Extra Terrestrial", yearCreated: 1980);
            Console.WriteLine(divider);

            List<object> test = new List<object> { movie1, movie2, movie3 };
            foreach(int i in Enumerable.Range(0, 3)){
                Console.WriteLine(test[i]);
            }
            Console.WriteLine(divider);

            //Part 2
            Console.WriteLine("\nPart II");
            Console.WriteLine(divider);
            (VideoTypes type, string title, int year)[]? movies = { movie1, movie2, movie3 };

            for (int i = 0; i < movies.Length; i++) {
                Console.WriteLine(movies[i]);
            }

            Console.WriteLine("\n");

            // show that arrays are merely copies...
            movie3.title = "Here is a new title";
            for (int i = 0; i < movies.Length; i++)
            {
                Console.WriteLine(movies[i]);
            }
            Console.WriteLine("\n");

            //actual update in the array
            movies[2].title = "Finally making change in the array...";
            for (int i = 0; i < movies.Length; i++)
            {
                Console.WriteLine(movies[i]);
            }
            Console.WriteLine("\n");

            var moviesTemp = new (VideoTypes type, string title, int year)[movies.Length + 1];
            Array.Copy(movies, moviesTemp, movies.Length);
            movies = moviesTemp;
            moviesTemp = null;
            var movie4 = (type: VideoTypes.DVD, title: "Jurassic Park", year: 1998);
            movies[movies.Length - 1] = movie4;
            for (int i = 0; i < movies.Length; i++)
            {
                Console.WriteLine(movies[i]);
            }

            Console.WriteLine(divider);
            Console.WriteLine("\n");

            //Part III
            Console.WriteLine("Part III");
            Console.WriteLine(divider);
            List<(VideoTypes type, string title, int year)> movieList = new List<(VideoTypes type, string title, int year)>() { movie1, movie2, movie3 };
            Console.WriteLine(string.Join(", ", movieList));
            movieList.Add(movie4);
            Console.WriteLine(string.Join(", ", movieList));

            var firstTwo = movieList[0..2];
            var lastTwo = movieList[(movieList.Count-2)..movieList.Count];
            var middleTwo = movieList[1..3];

            Console.WriteLine(string.Join(", ", firstTwo));
            Console.WriteLine(string.Join(", ", lastTwo));
            Console.WriteLine(string.Join(", ", middleTwo));


            //Extra Credit
            Console.WriteLine(divider);
            Console.WriteLine("\n");
            Console.WriteLine("Extra Credit");
            Console.WriteLine(divider);

            List<int> ecList = new List<int>();

            foreach (int num in Enumerable.Range(0, 21)) {
                ecList.Add(num);
            }

            Console.WriteLine(string.Join(", ", ecList));
            Console.WriteLine("The count is " + ecList.Count);
            ecList.Insert(0, 45);

            Console.WriteLine(divider);
            Console.WriteLine("We have changed the first number to " + ecList.First());
            Console.WriteLine(string.Join(", ", ecList));
            Console.WriteLine("Now the count is " + ecList.Count);

            Console.WriteLine(divider);
            ecList.RemoveAt(0);
            Console.WriteLine("We have changed the first number back to " + ecList.First());
            Console.WriteLine(string.Join(", ", ecList));
            Console.WriteLine("Now the count is returned to " + ecList.Count);

            Console.WriteLine(divider);
            int[] change = ecList.ToArray();
            foreach (int i in change) {
                Console.WriteLine(i);
            }
        }
        enum VideoTypes {Unknown = 0, Film, VHS, Laserdisk, DVD, Bluray, Digital};
        }
    }

